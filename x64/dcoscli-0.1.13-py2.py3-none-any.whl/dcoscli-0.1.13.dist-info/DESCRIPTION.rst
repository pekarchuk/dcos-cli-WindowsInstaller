DCOS Command Line Interface
===========================
The DCOS Command Line Interface (CLI) is a command line utility that
provides a user-friendly yet powerful way to manage DCOS installations.

This project is open source. Please see GitHub_ to access source code and to contribute.

Full documentation is available for the DCOS CLI on the `Mesosphere docs website`_.

.. _GitHub: https://github.com/mesosphere/dcos-cli
.. _Mesosphere docs website: http://docs.mesosphere.com/using/cli/


