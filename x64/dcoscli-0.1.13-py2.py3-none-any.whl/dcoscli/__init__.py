# Version is set for releases by our build system.
# Be extremely careful when modifying.
version = '0.1.13'
"""DCOS CLI version"""
